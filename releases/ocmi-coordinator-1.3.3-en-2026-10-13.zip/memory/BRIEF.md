# Coordinator scope and choices

Status: template. Updated: [date].

- Coordinator directory and reading boundary: [system folder]/.local/coordinator; [confirmed path].
- Communication language / template edition: [confirmed languages].
- Local OCMI system folder: [confirmed local location].
- Client project/workspace and folder binding: [planned / confirmed; evidence source and date].
- Coordinator chat in this project: [pending / initialized with evidence].
- Source origin and commit/tag: [verified identity / unknown with verification limit].
- Installed OCMI version: [verified version]. All profiles use the system release number.
- Restoration prompt: [STARTUP](../STARTUP.md).
- Core setup authority: [current request selecting installation and both core locations].

## User-selected setup

| Option | Selection | Target / source of choice |
| --- | --- | --- |
| Local system and coordinator handover | [confirmed selection] | [core locations] |
| Folder organization or renaming | not selected | none |
| Personal storage | not selected | none |
| Work-project integration | not selected | none |

Fill from current authority; suggestions are not selections.
Each target has its own scope. Project permissions, models and budgets are not inherited.
Keep sensitive details in their own authorized areas; no personal profile is needed here.
