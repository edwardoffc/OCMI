# Prepare coordinator service memory

**OCMI coordinator 1.3.1, 2026-10-12**

Use after the user selects guided system installation and both core locations.
This profile provides the file handover to a separate coordinator chat, not personal topics.
For the complete local system requirement, read docs/install-system.md in the chosen system edition.

1. Verify the selected private directory is outside the source checkout and public Git scope.
   Read only its applicable instructions and setup records. Preserve WIP and history.
   Keep an existing coordinator location; do not create a competing brief, registry or handoff.
2. Copy AGENTS.md, VERSION.md, LICENSE, STARTUP.md and memory/ into a new target;
   INSTALL.md is optional. Choose one language edition and preserve its stable paths.
   Merge existing records carefully; never overwrite populated memory with blank templates.
3. Fill confirmed core locations, source identity, versions and languages in BRIEF/INDEX.
   Record actual status and remaining handover in HANDOFF. Personal storage is not a prerequisite;
   folder organization and project integration remain not selected.
4. Replace every STARTUP prompt token with confirmed values. Save the filled prompt privately
   and give identical text to the user. Check links, prompt fields and target access.
   Unknown revision must include its verification limit; missing paths require clarification.
5. Tell the user to create a project attached to the system folder and a separate coordinator chat;
   clients without projects can use a separate chat with file access.
   If the service directory is inaccessible, request access to that exact directory.
   Installed files are not proof of coordinator initialization: only the new chat can confirm it.
6. Keep the installer chat until that coordinator records successful handover.
   Future chats use the saved startup prompt and current private handoff; no installer history required.

## Boundary

Store only nonsensitive setup metadata and necessary pointers. Sanitize evidence before saving.
Do not copy project plans, code, personal facts, client histories or secrets.
Do not move sensitive originals into shared memory or infer permissions from registry entries.
Source templates are read for selected installations/upgrades; installed projects remain self-contained.
Folder names are suggestions; renaming, chat actions, publication and global settings need their own authority.
