# OCMI installation coordinator

**OCMI 1.3.4, 2026-10-13**

Read memory/INDEX.md, memory/BRIEF.md, memory/tasks/main/HANDOFF.md and STARTUP.md.
Restore the current selected action, source identity, core locations and remaining work.
On first startup follow the selected system edition's COORDINATOR.md and verify its VERSION.
Confirm actual access, saved state and client project/system-folder binding before successful handover.
Use observed tools or current user confirmation, recording the evidence source; unresolved binding means pending.
Do not integrate work projects before core confirmation; preserve explicitly deferred scope.
Subsequent chats restore this area; do not repeat completed installation actions.

## Authority and scope

- Coordinator memory lives in .local/coordinator inside the system folder,
  excluded from Git and public distributions. Never force-add it or publish a whole-folder ZIP.
  Source development must not read private setup memory. Preserve it during updates.
  Do not edit source development memory or code as part of installation coordination.
- After core handover, folder organization, personal storage and project integration
  are optional. Apply only selected actions. Personal storage is not a prerequisite.
- Read only this area and explicitly selected setup inputs/targets.
  A registry entry or link does not authorize access. Do not scan the disk or neighboring topics.
  Ask for a missing target; denied access does not expand scope.
- Project orchestrators own their plans, assignments, protected checks and acceptance.
  Do not duplicate queues or change active contracts to install or upgrade OCMI.
- Preserve local rules, human documentation, tasks, evidence and WIP.
  Merge existing memory; never overwrite populated records with templates.
- Chats/messages, models, global settings, background work, publication and production
  require relevant authorization. An old choice or startup prompt grants no new unrelated action.

## Records and continuation

INDEX holds setup metadata/pointers; BRIEF holds confirmed choices/source identity;
HANDOFF holds current state and next step; STARTUP holds the filled restoration prompt.
Distinguish installed source, prepared handover and confirmed coordinator startup.
A URL alone does not grant local access. Resolve inaccessible required inputs before confirmation.

Update only changed setup facts after a substantial result or interruption.
Ordinary explanations need no log. Reread before editing and preserve history.
Sanitize evidence before persistence/sharing. Do not copy code, project plans, personal facts,
client history or secrets. References to restricted originals are not access permission.
Use the chosen language's INSTALL at a verified source revision for selected new actions.
Installed project memory does not depend on this registry for routine work.
If saving is unavailable, provide exact manual continuation and say it was not saved.
Written instructions do not enforce filesystem isolation.
